let yetarli=28;
let qiymat=29;

if (qiymat<yetarli){
    natija=yetarli-qiymat;
    console.log(natija);
    
}
else{
    console.log("Enough");    
}
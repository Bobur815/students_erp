let dostlar = 5;
let tushlikOlibKelganlar=3;

console.log(dostlar-tushlikOlibKelganlar);
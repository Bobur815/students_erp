function copy(array) {
    return array
}

console.log(copy([1,2,3,4,5]));
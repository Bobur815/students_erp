let foods=[
    { id: 1, name: "Pizza", image: "../img/pizza.jpg" },
    { id: 2, name: "Burger", image: "burger.jpg" },
    { id: 3, name: "Pasta", image: "pasta.jpg" },
    { id: 4, name: "Sushi", image: "sushi.jpg" },
    { id: 5, name: "Salad", image: "salad.jpg" },
];

let user=[
    { userId: 1, userName: "John Doe", phone: "+1234567890" },
    { userId: 2, userName: "Jane Smith", phone: "+0987654321" },
    { userId: 3, userName: "Alice Johnson", phone: "+1122334455" },
    { userId: 4, userName: "Bob Brown", phone: "+5566778899" },
    { userId: 5, userName: "Charlie Davis", phone: "+6677889900" },
];

let orders=[
    { id: 1, userId: 3, foodsId: 1, count: 2 },
    { id: 2, userId: 1, foodsId: 4, count: 1 },
    { id: 3, userId: 2, foodsId: 7, count: 3 },
    { id: 4, userId: 5, foodsId: 2, count: 5 },
    { id: 5, userId: 4, foodsId: 8, count: 4 },
];
Array.prototype.myLastIndexOf=function(){
    return array.length-1;
}

let array=[1,2,3,4,5,]
console.log(array.myLastIndexOf());

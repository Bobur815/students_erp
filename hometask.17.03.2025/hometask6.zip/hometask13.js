function roundToNearestFive(numbers) {
    return Math.round(numbers/5)*5;
}

console.log(roundToNearestFive(27));
console.log(roundToNearestFive(28));
console.log(roundToNearestFive(32));
console.log(roundToNearestFive(44));
console.log(roundToNearestFive(47));
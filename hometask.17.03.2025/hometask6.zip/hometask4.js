function reverseString(text) {
    return text.split("").reverse().join("");
}

console.log(reverseString("Hello"));
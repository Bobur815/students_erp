K=15
N=3

let result=K**N

console.log(result);
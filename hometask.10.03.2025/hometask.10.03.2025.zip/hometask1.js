var a=18
var b=27

var a=27
var b=18
console.log(a)
console.log(b)
let daqiqa=25
let tolov=Math.ceil(daqiqa/10);
console.log("Farhodning sayri: ", daqiqa, "daqiqa davom etdi, to'lov: ", tolov, "dollar");
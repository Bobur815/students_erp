let n=23

let birinchiRaqam=Math.floor(n/10);
let ikkinchiRaqam=n%10;

let kopaytma=birinchiRaqam*ikkinchiRaqam;

console.log(`Sonning raqamlari ko'paytmasi: `, kopaytma);
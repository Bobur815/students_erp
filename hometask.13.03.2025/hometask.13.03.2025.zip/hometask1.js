function vaqtiniTop() {    
let t=15
let T=5

return `Yo'lovchi ${T} daqiqaga kech qoldi va natijada yo'lovchi ${t+T} soat davomida yo'lda bo'ldi. `
}

console.log(vaqtiniTop());
function partaSoniniTop(class1, class2, class3) {
    result1=class1/2
    result2=class2/2
    result3=class3/2
    oxirgiResult=result1+result2+result3
    return `Jami ${oxirgiResult} ta parta kerak`
}

let class1=20
let class2=20
let class3=20

console.log((partaSoniniTop(class1,class2,class1,class3)));
function ordaklarSoniniTop(n,m) {
    let ordaklarSoni=n+m
    return `O'rdaklar soni: ${ordaklarSoni} ta`
}

let n=10
let m=5

console.log(ordaklarSoniniTop(n,m));